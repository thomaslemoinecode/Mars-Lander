#include "mars_common.h"

int sem_ids[6];
double *ptr_shm[6];
double err_integ = 0.0;

void arret(int sig) {
    SHOW_CURSOR();
    printf("\n" MAG "[GUIDAGE] Deconnexion." RST "\n");
    exit(0);
}

void controle_step(int sig) {
    double consigne, mesure, cmd;
    
    sem_prendre(sem_ids[0], 0); consigne = *ptr_shm[0]; sem_rendre(sem_ids[0], 0);
    sem_prendre(sem_ids[1], 0); mesure   = *ptr_shm[1]; sem_rendre(sem_ids[1], 0);

    double erreur = consigne - mesure;
    err_integ += erreur * 0.25; 
    double Kp = 1600.0, Ki = 50.0;
    cmd = Kp * erreur + Ki * err_integ;

    if (cmd < 0.0) cmd = 0.0;
    if (cmd > MAX_THRUST) cmd = MAX_THRUST;

    sem_prendre(sem_ids[2], 0); *ptr_shm[2] = cmd; sem_rendre(sem_ids[2], 0);

    // Affichage Barre de Puissance
    printf("\033[H");
    printf(MAG  "╔══════════════════════════════════════╗\n");
    printf(MAG  "║        GUIDANCE COMPUTER (ECU)       ║\n");
    printf(MAG  "╠══════════════════════════════════════╣\n" RST);
    printf("║ CIBLE    : %9.2f m/s           ║\n", consigne);
    printf("║ MESURE   : %9.2f m/s           ║\n", mesure);
    printf("║ ERREUR   : %9.2f m/s           ║\n", erreur);
    printf(MAG  "╠══════════════════════════════════════╣\n" RST);
    
    // Barre visuelle
    int bar = (int)((cmd / MAX_THRUST) * 20.0);
    printf("║ PWR: [");
    for(int i=0; i<20; i++) {
        if(i < bar) printf(MAG "▓" RST);
        else printf("░");
    }
    printf("] %3.0f%% ║\n", (cmd/MAX_THRUST)*100);
    printf(MAG  "╚══════════════════════════════════════╝\n" RST);
    
    fflush(stdout);
}

int main(void) {
    int clefs[] = {CLEF_SHM_CONSIGNE, CLEF_SHM_VITESSE, CLEF_SHM_COMMANDE, 
                   CLEF_SHM_POSITION, CLEF_SHM_PENTE, CLEF_SHM_VENT};
    signal(SIGTERM, arret);
    HIDE_CURSOR();
    CLS();

    printf("Init...\n");
    for(int i=0; i<6; i++) {
        int shmid = shmget(clefs[i], sizeof(double), 0666);
        ptr_shm[i] = (double*)shmat(shmid, 0, 0);
        sem_ids[i] = semget(clefs[i], 1, 0666);
    }

    int id_msg = msgget(CLEF_MESSAGERIE, 0666);
    msgform msg = {TYPE_SERVEUR, getpid(), "GUIDANCE"};
    msgsnd(id_msg, &msg, sizeof(msg)-sizeof(long), 0);

    printf("Attente RDV...\n");
    int id_rdv = semget(CLEF_RDV, 1, 0666);
    sem_prendre(id_rdv, 0);

    CLS();
    struct sigaction sa;
    sa.sa_handler = controle_step;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;
    sigaction(SIGALRM, &sa, NULL);

    struct itimerval t;
    t.it_value.tv_sec = 0; t.it_value.tv_usec = 250000;
    t.it_interval = t.it_value;
    setitimer(ITIMER_REAL, &t, NULL);

    while(1) pause();
    return 0;
}
