#include "mars_common.h"

int shm_ids[6], sem_ids[6], id_rdv, id_msg;
int pid_phys = 0, pid_guid = 0, pid_env = 0;

void cleanup(int sig) {
    SHOW_CURSOR();
    printf("\n\n" RED "[ALERTE] ARRET MISSION (SIGNAL %d)" RST "\n", sig);
    
    if (pid_phys) kill(pid_phys, SIGTERM);
    if (pid_guid) kill(pid_guid, SIGTERM);
    if (pid_env)  kill(pid_env,  SIGTERM);
    sleep(1);

    printf("[INFO] Nettoyage RAM...\n");
    for(int i=0; i<6; i++) {
        shmctl(shm_ids[i], IPC_RMID, 0);
        semctl(sem_ids[i], 0, IPC_RMID);
    }
    semctl(id_rdv, 0, IPC_RMID);
    msgctl(id_msg, IPC_RMID, 0);

    printf(GRN "[OK] Systeme eteint proprement.\n" RST);
    exit(0);
}

int main(void) {
    signal(SIGINT, cleanup);
    signal(SIGTERM, cleanup);
    CLS();

    printf(BLU  "╔══════════════════════════════════════════╗\n");
    printf(BLU  "║       MISSION CONTROL CENTER v2.0        ║\n");
    printf(BLU  "╚══════════════════════════════════════════╝\n" RST);

    // 1. ALLOCATION
    printf(" 1. Allocation Memoire Partagée... ");
    id_msg = msgget(CLEF_MESSAGERIE, IPC_CREAT | 0666);
    msgctl(id_msg, IPC_RMID, 0); // Reset file
    id_msg = msgget(CLEF_MESSAGERIE, IPC_CREAT | 0666);

    id_rdv = semget(CLEF_RDV, 1, IPC_CREAT | 0666);
    semctl(id_rdv, 0, SETVAL, 0);

    int clefs[] = {CLEF_SHM_CONSIGNE, CLEF_SHM_VITESSE, CLEF_SHM_COMMANDE, 
                   CLEF_SHM_POSITION, CLEF_SHM_PENTE, CLEF_SHM_VENT};
    double init_vals[] = {-2.0, -50.0, 0.0, 1000.0, 0.0, 0.0}; 

    for(int i=0; i<6; i++) {
        shm_ids[i] = shmget(clefs[i], sizeof(double), IPC_CREAT | 0666);
        double *ptr = (double*)shmat(shm_ids[i], 0, 0);
        *ptr = init_vals[i];
        shmdt(ptr);

        sem_ids[i] = semget(clefs[i], 1, IPC_CREAT | 0666);
        semctl(sem_ids[i], 0, SETVAL, 1);
    }
    printf(GRN "[OK]\n" RST);

    // 2. SYNCHRO
    printf(" 2. Attente des sous-systemes...\n");
    
    msgform msg;
    int connected = 0;
    while(connected < 3) {
        msgrcv(id_msg, &msg, sizeof(msg)-sizeof(long), TYPE_SERVEUR, 0);
        if (strcmp(msg.mtext, "PHYSICS") == 0) pid_phys = msg.pid;
        else if (strcmp(msg.mtext, "GUIDANCE") == 0) pid_guid = msg.pid;
        else if (strcmp(msg.mtext, "ENV") == 0) pid_env = msg.pid;
        
        printf("    > Module detecte : " CYN "%-10s" RST " (PID %d)\n", msg.mtext, msg.pid);
        connected++;
    }

    printf(" 3. Synchronisation temporelle...  " GRN "[PRET]\n" RST);
    printf("\n" YEL "LANCEMENT DANS 3 SECONDES...\n" RST);
    sleep(1); printf(" 3...\n"); sleep(1); printf(" 2...\n"); sleep(1); printf(" 1...\n");

    // Top Départ
    semctl(id_rdv, 0, SETVAL, 4); 
    
    printf("\n" GRN ">>> MISSION EN COURS - MONITORING ACTIF <<<" RST "\n");
    printf("(Ctrl+C pour avorter la mission)\n");

    while(1) pause();
    return 0;
}
