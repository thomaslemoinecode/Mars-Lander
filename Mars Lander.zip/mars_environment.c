#include "mars_common.h"

int sem_ids[6];
double *ptr_shm[6];

void arret(int sig) {
    SHOW_CURSOR();
    printf("\n" YEL "Deconnexion." RST "\n");
    exit(0);
}

int main(void) {
    int clefs[] = {CLEF_SHM_CONSIGNE, CLEF_SHM_VITESSE, CLEF_SHM_COMMANDE, 
                   CLEF_SHM_POSITION, CLEF_SHM_PENTE, CLEF_SHM_VENT};
    signal(SIGTERM, arret);
    
    for(int i=0; i<6; i++) {
        int shmid = shmget(clefs[i], sizeof(double), 0666);
        ptr_shm[i] = (double*)shmat(shmid, 0, 0);
        sem_ids[i] = semget(clefs[i], 1, 0666);
    }

    int id_msg = msgget(CLEF_MESSAGERIE, 0666);
    msgform msg = {TYPE_SERVEUR, getpid(), "ENV"};
    msgsnd(id_msg, &msg, sizeof(msg)-sizeof(long), 0);

    int id_rdv = semget(CLEF_RDV, 1, 0666);
    sem_prendre(id_rdv, 0);

    int choix;
    double vent_cible = 0.0;

    while(1) {
        CLS();
        // Lecture pour affichage
        sem_prendre(sem_ids[3], 0); double alt = *ptr_shm[3]; sem_rendre(sem_ids[3], 0);
        sem_prendre(sem_ids[5], 0); double vent = *ptr_shm[5]; sem_rendre(sem_ids[5], 0);

        printf(YEL "╔══════════════════════════════════════╗\n");
        printf(YEL "║      MARS ENVIRONMENT CONTROL        ║\n");
        printf(YEL "╠══════════════════════════════════════╣\n" RST);
        printf("║ ALTITUDE : %9.1f m             ║\n", alt);
        printf("║ VENT ACT : %9.1f m/s             ║\n", vent);
        printf(YEL "╠══════════════════════════════════════╣\n" RST);
        printf("║ 1. Calme plat       (0 m/s)          ║\n");
        printf("║ 2. Ascendance       (+20 m/s)        ║\n");
        printf("║ 3. Rabattant        (-20 m/s)        ║\n");
        printf("║ 4. Tempete Majeure  (-50 m/s)        ║\n");
        printf("║ 5. Quitter                           ║\n");
        printf(YEL "╚══════════════════════════════════════╝\n" RST);
        printf(" Choix > ");
        
        if (scanf("%d", &choix) != 1) break;

        if (choix == 1)      vent_cible = 0.0;
        else if (choix == 2) vent_cible = 20.0;
        else if (choix == 3) vent_cible = -20.0;
        else if (choix == 4) vent_cible = -50.0;
        else if (choix == 5) return 0;
        else continue;

        sem_prendre(sem_ids[5], 0);
        *ptr_shm[5] = vent_cible;
        sem_rendre(sem_ids[5], 0);
        
        printf("\n" GRN ">>> INJECTION VENT : %.1f m/s ! <<<\n" RST, vent_cible);
        sleep(1);
    }
    return 0;
}
