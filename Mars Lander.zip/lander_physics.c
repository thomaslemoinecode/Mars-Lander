#include "mars_common.h"

int sem_ids[6];
double *ptr_shm[6];
double vit_k, alt_k; 

void arret(int sig) {
    SHOW_CURSOR();
    printf("\n" CYN "[PHYSIQUE] Deconnexion." RST "\n");
    for(int i=0; i<6; i++) shmdt(ptr_shm[i]);
    exit(0);
}

void simulation_step(int sig) {
    double cmd, vent;
    double f_poids, f_trainee, f_moteur, accel;
    double vit_next, alt_next;
    double dt = 0.1; 

    // Lecture Protégée
    sem_prendre(sem_ids[2], 0); cmd = *ptr_shm[2]; sem_rendre(sem_ids[2], 0);
    sem_prendre(sem_ids[5], 0); vent = *ptr_shm[5]; sem_rendre(sem_ids[5], 0);

    // Calculs
    f_poids = -1.0 * MASSE_LANDER * GRAVITE;
    double v_rel = vit_k - vent;
    f_trainee = 0.5 * RHO_ATM * CX * SURFACE_REF * v_rel * fabs(v_rel);
    if (v_rel > 0) f_trainee *= -1.0; else f_trainee *= 1.0;
    f_moteur = cmd;
    accel = (f_poids + f_trainee + f_moteur) / MASSE_LANDER;
    vit_next = vit_k + accel * dt;
    alt_next = alt_k + vit_k * dt;

    // Ecriture Protégée
    sem_prendre(sem_ids[1], 0); *ptr_shm[1] = vit_next; sem_rendre(sem_ids[1], 0);
    sem_prendre(sem_ids[3], 0); *ptr_shm[3] = alt_next; sem_rendre(sem_ids[3], 0);
    vit_k = vit_next; alt_k = alt_next;

    // --- AFFICHAGE LUXE ---
    printf("\033[H"); // Retour Home (0,0)
    printf(CYN  "╔══════════════════════════════════════╗\n");
    printf(CYN  "║      LANDER PHYSICS TELEMETRY        ║\n");
    printf(CYN  "╠══════════════════════════════════════╣\n" RST);
    printf("║ " BOLD "ALTITUDE" RST " : %9.2f m             ║\n", alt_k);
    printf("║ " BOLD "VITESSE " RST " : %9.2f m/s           ║\n", vit_k);
    printf("║ " BOLD "ACCEL   " RST " : %9.2f m/s²          ║\n", accel);
    printf(CYN  "╠══════════════════════════════════════╣\n" RST);
    printf("║ MOTEUR   : %9.0f N             ║\n", cmd);
    printf("║ VENT     : %9.1f m/s           ║\n", vent);
    printf(CYN  "╚══════════════════════════════════════╝\n" RST);
    fflush(stdout);

    if (alt_k <= 0) {
        SHOW_CURSOR();
        printf("\n");
        if (fabs(vit_k) < 5.0) printf(GRN ">>> TOUCHDOWN REUSSI ! (%.2f m/s) <<<\n" RST, vit_k);
        else                   printf(RED ">>> CRASH CRITIQUE ! (%.2f m/s) <<<\n" RST, vit_k);
        *ptr_shm[3] = 0.0;
        exit(0);
    }
}

int main(void) {
    int clefs[] = {CLEF_SHM_CONSIGNE, CLEF_SHM_VITESSE, CLEF_SHM_COMMANDE, 
                   CLEF_SHM_POSITION, CLEF_SHM_PENTE, CLEF_SHM_VENT};
    signal(SIGTERM, arret);
    HIDE_CURSOR();
    CLS();

    // Connexion
    printf("Initialisation...\n");
    for(int i=0; i<6; i++) {
        int shmid = shmget(clefs[i], sizeof(double), 0666);
        if (shmid == -1) { perror("Erreur SHM"); exit(1); }
        ptr_shm[i] = (double*)shmat(shmid, 0, 0);
        sem_ids[i] = semget(clefs[i], 1, 0666);
    }
    vit_k = *ptr_shm[1];
    alt_k = *ptr_shm[3];

    // Handshake
    int id_msg = msgget(CLEF_MESSAGERIE, 0666);
    msgform msg = {TYPE_SERVEUR, getpid(), "PHYSICS"};
    msgsnd(id_msg, &msg, sizeof(msg)-sizeof(long), 0);

    // RDV
    int id_rdv = semget(CLEF_RDV, 1, 0666);
    sem_prendre(id_rdv, 0);

    CLS(); // Nettoyage pour l'affichage final

    struct sigaction sa;
    sa.sa_handler = simulation_step;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;
    sigaction(SIGALRM, &sa, NULL);

    struct itimerval t;
    t.it_value.tv_sec = 0; t.it_value.tv_usec = 100000;
    t.it_interval = t.it_value;
    setitimer(ITIMER_REAL, &t, NULL);

    while(1) pause();
    return 0;
}
