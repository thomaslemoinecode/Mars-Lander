#ifndef MARS_COMMON_H
#define MARS_COMMON_H

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/msg.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <math.h>
#include <signal.h>
#include <sys/time.h>

// --- CLES IPC ---
#define CLEF_SHM_CONSIGNE 1001
#define CLEF_SHM_VITESSE  1002
#define CLEF_SHM_COMMANDE 1003
#define CLEF_SHM_POSITION 1004
#define CLEF_SHM_PENTE    1005
#define CLEF_SHM_VENT     1006

#define CLEF_RDV          2000
#define CLEF_MESSAGERIE   3000

// --- PHYSIQUE ---
#define MASSE_LANDER 600.0
#define GRAVITE      3.71
#define RHO_ATM      0.100 // Densité augmentée pour la démo
#define CX           1.5
#define SURFACE_REF  20.0  // Surface augmentée pour la démo
#define MAX_THRUST   20000.0

// --- STRUCTURES ---
#define TYPE_SERVEUR 1
typedef struct {
    long mtype;
    int pid;
    char mtext[20]; 
} msgform;

// --- SEMAPHORES (INLINE pour la perf) ---
static inline int sem_prendre(int semid, int ns) {
    struct sembuf op = {(unsigned short)ns, -1, 0};
    return semop(semid, &op, 1);
}

static inline int sem_rendre(int semid, int ns) {
    struct sembuf op = {(unsigned short)ns, 1, 0};
    return semop(semid, &op, 1);
}

// --- AFFICHAGE ANSI ---
#define RST  "\033[0m"
#define BOLD "\033[1m"
#define RED  "\033[1;31m"
#define GRN  "\033[1;32m"
#define YEL  "\033[1;33m"
#define BLU  "\033[1;34m"
#define MAG  "\033[1;35m"
#define CYN  "\033[1;36m"
#define WHT  "\033[1;37m"

// Efface l'écran et remet le curseur en haut à gauche
#define CLS() printf("\033[H\033[J")
#define HIDE_CURSOR() printf("\033[?25l")
#define SHOW_CURSOR() printf("\033[?25h")

#endif
